# Knowledge-Based Systems submission checklist

- [x] Elsevier two-column manuscript source and PDF prepared.
- [x] Main paper compiles to 13 pages with 35 resolved references.
- [x] Five Highlights supplied in a separate editable file; each is under 85 characters.
- [x] Threats to validity, statistical intervals, Wilcoxon/Holm tests, and Algorithm 1 are present.
- [x] Electronic supplementary material compiles independently.
- [x] KBS-specific cover letter and AI disclosure prepared.
- [x] Figures are high resolution and remain legible in the Elsevier layout.
- [ ] Confirm that the manuscript is not under consideration by another journal.
- [ ] Push tag `kbs-submission-v2` and its manifest to the public repository.
- [ ] Upload the manuscript, Highlights, supplement, cover letter, and source archive.